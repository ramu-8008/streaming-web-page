<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mlogin";
$x = $_POST['email'];
$y = $_POST['password'];

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error){
 die("Connection failed : ". $conn->connect_error);
}
 $sql = "INSERT INTO login(email,password) VALUES ('$x','$y')";
if ($conn->query($sql) === TRUE){
	echo "login Successfull successfully";
}else{
	echo "Error : ". $sql."<br>". $conn->error;
}
$conn->close();
?>
<?php 
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mregister";
$x = $_POST['fname'];
$y = $_POST['lname'];
$z = $_POST['email'];
$p = $_POST['password'];


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error){
 die("Connection failed : ". $conn->connect_error);
}
 $sql = "INSERT INTO register(fname,lname,email,password) VALUES ('$x','$y','$z','$p')";
if ($conn->query($sql) === TRUE){
	echo "Registration  Successfull successfully";
}else{
	echo "Error : ". $sql."<br>". $conn->error;
}
$conn->close();
?>
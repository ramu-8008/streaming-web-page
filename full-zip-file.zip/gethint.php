
<?php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "index"; 


$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
  die("Connection failed: " . mysql_connect_error());
}





$sql = "SELECT * from movies";

// $sql = "SELECT * from 
$result = mysqli_query($conn, $sql);





while($row=mysqli_fetch_array($result)){
      $a[]=$row['name'];
}




// // Array with names
// $a[] = "avatar";
// $a[] = "Bhaubhali";
// $a[] = "charlie";
// $a[] = "dia";
// $a[] = "specter";
// $a[] = "RRR";
// $a[] = "KGF";
// $a[] = "kantara";
// $a[] = "rowdy";
// $a[] = "akahanda";
// $a[] = "HIT";
// $a[] = "wakanda forever";
// $a[] = "endgame";
// $a[] = "civilwar";
// $a[] = "ultron";
// $a[] = "ironman 2";
// $a[] = "spiderman";
// $a[] = "gardians of the galaxy";
// $a[] = "black adam";
// $a[] = "superman";
// $a[] = "wonder women";
// $a[] = "black widow";
// $a[] = "captian marval";
// $a[] = "Unni";
// $a[] = "Violet";
// $a[] = "Liza";
// $a[] = "Elizabeth";
// $a[] = "Ellen";
// $a[] = "Wenche";
// $a[] = "Vicky";

// get the q parameter from URL
$q = $_REQUEST["q"];

$hint = "";

// lookup all hints from array if $q is different from ""
if ($q !== "") {
  $q = strtolower($q);
  $len=strlen($q);
  foreach($a as $name) {
    if (stristr($q, substr($name, 0, $len))) {
      if ($hint === "") {
        $hint = $name;
      } else {
        $hint .= ", $name";
      }
    }
  }
}

// Output "no suggestion" if no hint was found or output correct values
echo $hint === "" ? "no suggestion" : $hint;
?>

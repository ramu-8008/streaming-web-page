<?php
$servername = "localhost"; 
$username = "root"; 
$password = ""; 
$dbname = "mregister"; 


$conn = mysqli_connect($servername, $username, $password, $dbname);


if (!$conn) {
  die("Connection failed: " . mysql_connect_error());
}


if($_POST["email1"] == "Search") 
{

$sql = "SELECT * from register";
}
else  
{
  $v2=$_POST["email1"]; 
  $v3=$_POST["password1"]; 
  $sql = "SELECT * from register where password = $v3 AND email = $v2";
    
}

$result = mysqli_query($conn, $sql);


if (mysqli_num_rows($result) > 0) 
{

$row = mysqli_fetch_array($result);

    print "First name: " . $row["fname"]."<br><br>";
    print "Last Name: " . $row["lname"]."<br><br>";
    print "Email: " . $row["email"]."<br><br>";
    print "password : " . $row["password"]."<br><br>";
    print "*********************" ."<br><br>";
  
}
 

else 
{
  echo "0 results";
}

mysqli_close($conn);// close the database
?>
